import tkinter as tk
from tkinter import messagebox
import time
import random
import string

##Contact Node
class Contact:
    def __init__(self, name, phone):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None


##BST Directory
class ContactDirectory:
    def __init__(self):
        self.root = None

    def insert(self, root, name, phone):
        if root is None:
            return Contact(name, phone)

        if name < root.name:
            root.left = self.insert(root.left, name, phone)
        elif name > root.name:
            root.right = self.insert(root.right, name, phone)
        else:
            root.phone = phone

        return root

    def search(self, root, name):
        if root is None or root.name == name:
            return root

        if name < root.name:
            return self.search(root.left, name)
        else:
            return self.search(root.right, name)

    def find_min(self, root):
        current = root
        while current.left:
            current = current.left
        return current

    def delete(self, root, name):
        if root is None:
            return root

        if name < root.name:
            root.left = self.delete(root.left, name)
        elif name > root.name:
            root.right = self.delete(root.right, name)
        else:
            if root.left is None:
                return root.right
            elif root.right is None:
                return root.left

            temp = self.find_min(root.right)
            root.name = temp.name
            root.phone = temp.phone
            root.right = self.delete(root.right, temp.name)

        return root

    def inorder(self, root):
        if root:
            return self.inorder(root.left) + [(root.name, root.phone)] + self.inorder(root.right)
        return []



##GUI
class BSTVisualizerApp:
    def __init__(self, root):
        self.directory = ContactDirectory()
        self.root = root
        self.root.title("Contact Directory BST")

        frame = tk.Frame(root)
        frame.pack(pady=10)

        tk.Label(frame, text="Name:").grid(row=0, column=0)
        self.name_entry = tk.Entry(frame)
        self.name_entry.grid(row=0, column=1)

        tk.Label(frame, text="Phone:").grid(row=1, column=0)
        self.phone_entry = tk.Entry(frame)
        self.phone_entry.grid(row=1, column=1)

        btn_frame = tk.Frame(root)
        btn_frame.pack()

        tk.Button(btn_frame, text="Insert", command=self.insert_contact).grid(row=0, column=0)
        tk.Button(btn_frame, text="Search", command=self.search_contact).grid(row=0, column=1)
        tk.Button(btn_frame, text="Delete", command=self.delete_contact).grid(row=0, column=2)
        tk.Button(btn_frame, text="Show All", command=self.show_all).grid(row=0, column=3)

        self.output = tk.Text(root, height=10, width=50)
        self.output.pack()

    def insert_contact(self):
        name = self.name_entry.get()
        phone = self.phone_entry.get()

        if not name or not phone:
            messagebox.showwarning("Error", "Enter both fields")
            return

        self.directory.root = self.directory.insert(self.directory.root, name, phone)
        self.show_all()

    def search_contact(self):
        name = self.name_entry.get()
        node = self.directory.search(self.directory.root, name)

        self.output.delete(1.0, tk.END)
        if node:
            self.output.insert(tk.END, f"{node.name}: {node.phone}")
        else:
            self.output.insert(tk.END, "Not found")

    def delete_contact(self):
        name = self.name_entry.get()
        self.directory.root = self.directory.delete(self.directory.root, name)
        self.show_all()

    def show_all(self):
        self.output.delete(1.0, tk.END)
        for name, phone in self.directory.inorder(self.directory.root):
            self.output.insert(tk.END, f"{name}: {phone}\n")

##Run App
root = tk.Tk()
app = BSTVisualizerApp(root)
root.mainloop()
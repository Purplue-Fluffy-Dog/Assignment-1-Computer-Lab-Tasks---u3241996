import tkinter as tk
from tkinter import messagebox

NODE_WIDTH = 80
NODE_HEIGHT = 40
HORIZONTAL_GAP = 20
CANVAS_WIDTH = 900
CANVAS_HEIGHT = 220

class Queue:
    def __init__(self):
        self.items = []

    def enqueue(self, value):
        self.items.append(value)

    def dequeue(self):
        if self.is_empty():
            return None
        return self.items.pop(0)

    def is_empty(self):
        return len(self.items) == 0

    def to_list(self):
        return self.items[:]


class QueueVisualizer:
    def __init__(self, root):
        self.root = root
        self.root.title("Queue Visualizer")

        self.queue = Queue()

        self.canvas = tk.Canvas(root, width=CANVAS_WIDTH, height=CANVAS_HEIGHT, bg='white')
        self.canvas.pack(pady=20)

        control_frame = tk.Frame(root)
        control_frame.pack()

        tk.Label(control_frame, text="Enqueue Value:").grid(row=0, column=0)
        self.enqueue_entry = tk.Entry(control_frame, width=10)
        self.enqueue_entry.grid(row=0, column=1)

        enqueue_btn = tk.Button(control_frame, text="Enqueue", command=self.enqueue_value)
        enqueue_btn.grid(row=0, column=2, padx=5)

        dequeue_btn = tk.Button(control_frame, text="Dequeue", command=self.dequeue_value)
        dequeue_btn.grid(row=1, column=2, pady=5)

        self.status_label = tk.Label(root, text="", fg="blue", font=("Arial", 12))
        self.status_label.pack(pady=5)

        self.draw_queue()

    def draw_node(self, x, y, data):
        self.canvas.create_rectangle(
            x, y, x + NODE_WIDTH, y + NODE_HEIGHT,
            fill="lightgreen", outline="black", width=2
        )
        self.canvas.create_text(
            x + NODE_WIDTH / 2,
            y + NODE_HEIGHT / 2,
            text=str(data),
            font=("Arial", 16)
        )

    def draw_queue(self):
        self.canvas.delete("all")

        items = self.queue.to_list()
        x = 30
        y = (CANVAS_HEIGHT - NODE_HEIGHT) // 2

        for i, value in enumerate(items):
            self.draw_node(x, y, value)

            if i < len(items) - 1:
                self.canvas.create_line(
                    x + NODE_WIDTH, y + NODE_HEIGHT / 2,
                    x + NODE_WIDTH + HORIZONTAL_GAP, y + NODE_HEIGHT / 2,
                    arrow=tk.LAST, width=2
                )

            x += NODE_WIDTH + HORIZONTAL_GAP

        if items:
            front_x = 30 + NODE_WIDTH / 2
            rear_x = 30 + (len(items) - 1) * (NODE_WIDTH + HORIZONTAL_GAP) + NODE_WIDTH / 2

            self.canvas.create_text(
                front_x, y - 20,
                text="Front",
                font=("Arial", 12, "bold"),
                fill="red"
            )

            self.canvas.create_text(
                rear_x, y + NODE_HEIGHT + 20,
                text="Rear",
                font=("Arial", 12, "bold"),
                fill="blue"
            )
        else:
            self.canvas.create_text(
                CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2,
                text="Queue is Empty",
                font=("Arial", 14, "bold"),
                fill="gray"
            )

    def enqueue_value(self):
        try:
            value = int(self.enqueue_entry.get())
        except ValueError:
            messagebox.showerror("Invalid Input", "Please enter an integer value to enqueue.")
            return

        self.queue.enqueue(value)
        self.enqueue_entry.delete(0, tk.END)
        self.status_label.config(text=f"Enqueued {value} into queue")
        self.draw_queue()

    def dequeue_value(self):
        if self.queue.is_empty():
            messagebox.showinfo("Empty Queue", "Queue is empty. Cannot dequeue.")
            return

        value = self.queue.dequeue()
        self.status_label.config(text=f"Dequeued {value} from queue")
        self.draw_queue()


if __name__ == "__main__":
    root = tk.Tk()
    app = QueueVisualizer(root)

    root.mainloop()
from graph import Graph


# TASK 1: GRAPH BASICS

print("UNDIRECTED GRAPH TEST")
g = Graph()

g.add_vertex('A')
g.print_graph()
print()

g.add_vertex('B')
g.print_graph()
print()

g.add_vertex('C')
g.print_graph()
print()

g.add_vertex('D')
g.print_graph()
print()

g.add_edge('A', 'B')
g.print_graph()
print()

g.add_edge('B', 'C')
g.print_graph()
print()

g.add_edge('C', 'D')
g.print_graph()
print()

g.add_edge('A', 'D')
g.print_graph()
print()

print("Remove edge A-B")
g.remove_edge('A', 'B')
g.print_graph()
print()

print("Remove vertex C")
g.remove_vertex('C')
g.print_graph()
print()

print("BFS starting from vertex 'A':")
visited_bfs = g.bfs('A')
print("Visited vertices in BFS order:", visited_bfs)
print()


print("DIRECTED GRAPH TEST")
g_directed = Graph(directed=True)
g_directed.add_vertex('A')
g_directed.add_vertex('B')
g_directed.add_vertex('C')
g_directed.add_vertex('D')

g_directed.add_edge('A', 'B')
g_directed.print_graph()
print()

g_directed.add_edge('A', 'C')
g_directed.print_graph()
print()

g_directed.add_edge('B', 'D')
g_directed.print_graph()
print()

g_directed.add_edge('C', 'D')
g_directed.print_graph()
print()

print("Remove edge A-C")
g_directed.remove_edge('A', 'C')
g_directed.print_graph()
print()

print("Remove vertex D")
g_directed.remove_vertex('D')
g_directed.print_graph()
print()

print("BFS starting from vertex 'A':")
visited_bfs = g_directed.bfs('A')
print("Visited vertices in BFS order:", visited_bfs)
print()


print("WEIGHTED DIRECTED GRAPH TEST")
g_weighted = Graph(weighted=True, directed=True)
g_weighted.add_vertex('A')
g_weighted.add_vertex('B')
g_weighted.add_vertex('C')
g_weighted.add_vertex('D')

g_weighted.add_edge('A', 'B', 15)
g_weighted.print_graph()
print()

g_weighted.add_edge('B', 'C', 34)
g_weighted.print_graph()
print()

g_weighted.add_edge('C', 'D', 20)
g_weighted.print_graph()
print()

g_weighted.add_edge('A', 'D', 50)
g_weighted.print_graph()
print()

print("Remove edge B-C")
g_weighted.remove_edge('B', 'C')
g_weighted.print_graph()
print()

print("Remove vertex D")
g_weighted.remove_vertex('D')
g_weighted.print_graph()
print()

print("BFS starting from vertex 'A':")
visited_bfs = g_weighted.bfs('A')
print("Visited vertices in BFS order:", visited_bfs)
print()


# TASK 2 & 3: BFS AND DFS

print("BFS AND DFS TEST")
g_search = Graph(directed=True)

g_search.add_vertex('A')
g_search.add_vertex('B')
g_search.add_vertex('C')
g_search.add_vertex('D')

g_search.add_edge('A', 'B')
g_search.add_edge('A', 'C')
g_search.add_edge('B', 'D')
g_search.add_edge('C', 'D')
g_search.add_edge('D', 'A')   # cycle

g_search.print_graph()
print()

print("BFS starting from vertex 'A':")
visited_bfs = g_search.bfs('A')
print("Visited vertices in BFS order:", visited_bfs)
print()

print("DFS starting from vertex 'A':")
visited_dfs = g_search.dfs('A')
print("Visited vertices in DFS order:", visited_dfs)
print()


# TASK 4: CYCLE DETECTION

print("CYCLE DETECTION IN UNDIRECTED GRAPHS")

cycle_graph = Graph(directed=False)
for v in ['A', 'B', 'C']:
    cycle_graph.add_vertex(v)

cycle_graph.add_edge('A', 'B')
cycle_graph.add_edge('B', 'C')
cycle_graph.add_edge('C', 'A')

print("Does cycle_graph have a cycle?", cycle_graph.has_undirected_cycle())

acyclic_graph = Graph(directed=False)
for v in ['X', 'Y', 'Z']:
    acyclic_graph.add_vertex(v)

acyclic_graph.add_edge('X', 'Y')
acyclic_graph.add_edge('Y', 'Z')

print("Does acyclic_graph have a cycle?", acyclic_graph.has_undirected_cycle())
print()


# TASK 5: WEIGHTED AND DIRECTED GRAPH

print("WEIGHTED DIRECTED GRAPH")
wg = Graph(directed=True, weighted=True)

for v in ['A', 'B', 'C']:
    wg.add_vertex(v)

wg.add_edge('A', 'B', weight=15)
wg.add_edge('B', 'C', weight=34)
wg.add_edge('A', 'C', weight=50)

print("Weighted Directed Graph:")
wg.print_graph()
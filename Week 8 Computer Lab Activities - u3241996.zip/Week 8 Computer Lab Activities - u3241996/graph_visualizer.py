from graph import Graph
import tkinter as tk
from tkinter import simpledialog, messagebox
import math


class GraphVisualizer(tk.Tk):
    def __init__(self, graph):
        super().__init__()

        self.title("Graph Visualizer")
        self.geometry("700x600")

        self.graph = graph
        self.vertex_positions = {}
        self.vertex_items = {}

        # Top frame for buttons
        button_frame = tk.Frame(self)
        button_frame.pack(pady=10)

        tk.Button(button_frame, text="Add Vertex", command=self.add_vertex_gui).grid(row=0, column=0, padx=5)
        tk.Button(button_frame, text="Add Edge", command=self.add_edge_gui).grid(row=0, column=1, padx=5)
        tk.Button(button_frame, text="Remove Vertex", command=self.remove_vertex_gui).grid(row=0, column=2, padx=5)
        tk.Button(button_frame, text="Remove Edge", command=self.remove_edge_gui).grid(row=0, column=3, padx=5)
        tk.Button(button_frame, text="Run BFS", command=self.run_bfs_gui).grid(row=0, column=4, padx=5)
        tk.Button(button_frame, text="Run DFS", command=self.run_dfs_gui).grid(row=0, column=5, padx=5)
        tk.Button(button_frame, text="Redraw", command=self.draw_graph).grid(row=0, column=6, padx=5)

        # Canvas
        self.canvas = tk.Canvas(self, width=650, height=500, bg="white")
        self.canvas.pack(pady=10)

        self.draw_graph()

    def draw_graph(self):
        self.canvas.delete("all")
        self.vertex_positions = {}
        self.vertex_items = {}

        radius = 20
        spacing = 180
        n = len(self.graph.graph)

        if n == 0:
            return

        center_x, center_y = 325, 250
        angle_gap = 360 / n

        # Draw vertices in a circle
        for i, v in enumerate(self.graph.graph):
            angle_deg = i * angle_gap
            angle_rad = math.radians(angle_deg)

            x = center_x + spacing * math.cos(angle_rad)
            y = center_y + spacing * math.sin(angle_rad)

            self.vertex_positions[v] = (x, y)

        # Draw edges first
        for v in self.graph.graph:
            x1, y1 = self.vertex_positions[v]

            for nbr in self.graph.graph[v]:
                x2, y2 = self.vertex_positions[nbr]

                self.canvas.create_line(
                    x1, y1, x2, y2,
                    arrow=tk.LAST if self.graph.directed else None,
                    width=2
                )

                if self.graph.weighted:
                    w = self.graph.weights.get((v, nbr), "")
                    mid_x = (x1 + x2) / 2
                    mid_y = (y1 + y2) / 2
                    self.canvas.create_text(mid_x, mid_y, text=str(w), fill="red", font=("Arial", 10, "bold"))

        # Draw vertices on top
        for v in self.graph.graph:
            x, y = self.vertex_positions[v]

            oval = self.canvas.create_oval(
                x - radius, y - radius, x + radius, y + radius,
                fill="lightblue", outline="black", width=2
            )
            text = self.canvas.create_text(x, y, text=v, font=("Arial", 12, "bold"))

            self.vertex_items[v] = (oval, text)

    def highlight_traversal(self, traversal_order):
        self.draw_graph()
        self._highlight_step(traversal_order, 0)

    def _highlight_step(self, traversal_order, index):
        if index >= len(traversal_order):
            return

        vertex = traversal_order[index]
        if vertex in self.vertex_items:
            oval, _ = self.vertex_items[vertex]
            self.canvas.itemconfig(oval, fill="yellow")

        self.after(700, lambda: self._highlight_step(traversal_order, index + 1))

    def add_vertex_gui(self):
        vertex = simpledialog.askstring("Add Vertex", "Enter vertex name:")
        if vertex:
            self.graph.add_vertex(vertex)
            self.draw_graph()

    def add_edge_gui(self):
        vertex1 = simpledialog.askstring("Add Edge", "Enter start vertex:")
        vertex2 = simpledialog.askstring("Add Edge", "Enter end vertex:")

        if vertex1 and vertex2:
            if self.graph.weighted:
                weight = simpledialog.askinteger("Edge Weight", "Enter edge weight:", minvalue=0)
                if weight is None:
                    return
                self.graph.add_edge(vertex1, vertex2, weight)
            else:
                self.graph.add_edge(vertex1, vertex2)

            self.draw_graph()

    def remove_vertex_gui(self):
        vertex = simpledialog.askstring("Remove Vertex", "Enter vertex name:")
        if vertex:
            self.graph.remove_vertex(vertex)
            self.draw_graph()

    def remove_edge_gui(self):
        vertex1 = simpledialog.askstring("Remove Edge", "Enter start vertex:")
        vertex2 = simpledialog.askstring("Remove Edge", "Enter end vertex:")
        if vertex1 and vertex2:
            self.graph.remove_edge(vertex1, vertex2)
            self.draw_graph()

    def run_bfs_gui(self):
        start_vertex = simpledialog.askstring("Run BFS", "Enter start vertex:")
        if start_vertex:
            result = self.graph.bfs(start_vertex)
            if result:
                messagebox.showinfo("BFS Result", f"BFS Order: {result}")
                self.highlight_traversal(result)
            else:
                messagebox.showerror("Error", "Start vertex not found or traversal failed.")

    def run_dfs_gui(self):
        start_vertex = simpledialog.askstring("Run DFS", "Enter start vertex:")
        if start_vertex:
            result = self.graph.dfs(start_vertex)
            if result:
                messagebox.showinfo("DFS Result", f"DFS Order: {result}")
                self.highlight_traversal(result)
            else:
                messagebox.showerror("Error", "Start vertex not found or traversal failed.")


if __name__ == "__main__":
    g = Graph(directed=True, weighted=True)

    g.add_vertex('A')
    g.add_vertex('B')
    g.add_vertex('C')
    g.add_vertex('D')

    g.add_edge('A', 'B', 10)
    g.add_edge('A', 'C', 15)
    g.add_edge('B', 'D', 20)
    g.add_edge('C', 'D', 25)

    app = GraphVisualizer(g)
    app.mainloop()
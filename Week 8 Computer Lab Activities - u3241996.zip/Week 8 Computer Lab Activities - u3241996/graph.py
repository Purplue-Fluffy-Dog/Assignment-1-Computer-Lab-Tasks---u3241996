class Graph:
    def __init__(self, directed=False, weighted=False):
        # adjacency list
        self.graph = {}
        self.weights = {}
        self.directed = directed
        self.weighted = weighted

    def add_vertex(self, vertex):
        if vertex not in self.graph:
            self.graph[vertex] = []

    def add_edge(self, vertex1, vertex2, weight=0):
        if vertex1 in self.graph and vertex2 in self.graph:
            if vertex2 not in self.graph[vertex1]:
                self.graph[vertex1].append(vertex2)
                if self.weighted:
                    self.weights[(vertex1, vertex2)] = weight

            if not self.directed:
                if vertex1 not in self.graph[vertex2]:
                    self.graph[vertex2].append(vertex1)
                    if self.weighted:
                        self.weights[(vertex2, vertex1)] = weight
        else:
            print("One or both vertices not found in graph.")

    def remove_edge(self, vertex1, vertex2):
        if vertex1 in self.graph and vertex2 in self.graph:
            if vertex2 in self.graph[vertex1]:
                self.graph[vertex1].remove(vertex2)
                if self.weighted and (vertex1, vertex2) in self.weights:
                    del self.weights[(vertex1, vertex2)]

            if not self.directed:
                if vertex1 in self.graph[vertex2]:
                    self.graph[vertex2].remove(vertex1)
                    if self.weighted and (vertex2, vertex1) in self.weights:
                        del self.weights[(vertex2, vertex1)]
        else:
            print("One or both vertices not found in graph.")

    def remove_vertex(self, vertex):
        if vertex in self.graph:
            for v in self.graph:
                if vertex in self.graph[v]:
                    self.graph[v].remove(vertex)
                    if self.weighted and (v, vertex) in self.weights:
                        del self.weights[(v, vertex)]

            if self.weighted:
                keys_to_remove = []
                for edge in self.weights:
                    if edge[0] == vertex or edge[1] == vertex:
                        keys_to_remove.append(edge)

                for key in keys_to_remove:
                    del self.weights[key]

            del self.graph[vertex]
        else:
            print(f"Vertex {vertex} not found in graph.")

    def print_graph(self):
        print("Graph:")
        for vertex in self.graph:
            if self.weighted:
                edges = []
                for neighbour in self.graph[vertex]:
                    weight = self.weights.get((vertex, neighbour), 0)
                    edges.append(f"{neighbour}({weight})")
                print(f"{vertex} -> {edges}")
            else:
                print(f"{vertex} -> {self.graph[vertex]}")

    def bfs(self, start_vertex):
        if start_vertex not in self.graph:
            print("Start vertex not found.")
            return []

        visited = []
        queue = [start_vertex]

        while queue:
            current = queue.pop(0)

            if current not in visited:
                visited.append(current)

                for neighbour in self.graph[current]:
                    if neighbour not in visited and neighbour not in queue:
                        queue.append(neighbour)

        return visited

    def dfs(self, start_vertex):
        if start_vertex not in self.graph:
            print("Start vertex not found.")
            return []

        visited = []
        stack = [start_vertex]

        while stack:
            current = stack.pop()

            if current not in visited:
                visited.append(current)

                for neighbour in reversed(self.graph[current]):
                    if neighbour not in visited:
                        stack.append(neighbour)

        return visited

    def has_undirected_cycle(self):
        visited = set()

        for vertex in self.graph:
            if vertex not in visited:
                if self._dfs_cycle(vertex, visited, None):
                    return True
        return False

    def _dfs_cycle(self, current, visited, parent):
        visited.add(current)

        for neighbour in self.graph[current]:
            if neighbour not in visited:
                if self._dfs_cycle(neighbour, visited, current):
                    return True
            elif neighbour != parent:
                return True



        return False
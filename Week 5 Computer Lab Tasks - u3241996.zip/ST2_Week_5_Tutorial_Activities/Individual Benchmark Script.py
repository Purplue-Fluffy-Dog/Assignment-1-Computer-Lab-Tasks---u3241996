import random
import timeit

# -----------------------------
# MERGE SORT
# -----------------------------
def merge_sort(array):
    if len(array) <= 1:
        return array
    else:
        left_split = array[:len(array) // 2]
        right_split = array[len(array) // 2:]

        left = merge_sort(left_split)
        right = merge_sort(right_split)

        return merge(left, right)


def merge(left, right):
    merged = []
    left_pointer = 0
    right_pointer = 0

    while left_pointer < len(left) and right_pointer < len(right):
        if left[left_pointer] < right[right_pointer]:
            merged.append(left[left_pointer])
            left_pointer += 1
        elif right[right_pointer] < left[left_pointer]:
            merged.append(right[right_pointer])
            right_pointer += 1
        else:
            merged.append(left[left_pointer])
            merged.append(right[right_pointer])
            left_pointer += 1
            right_pointer += 1

    merged.extend(left[left_pointer:])
    merged.extend(right[right_pointer:])
    return merged


# -----------------------------
# INSERTION SORT
# -----------------------------
def insertion_sort(arr):
    for i in range(1, len(arr)):
        current_element = arr[i]
        j = i - 1

        while j >= 0 and current_element < arr[j]:
            arr[j + 1] = arr[j]
            j -= 1

        arr[j + 1] = current_element

    return arr


# -----------------------------
# BENCHMARK TEST
# -----------------------------
print("Benchmarking Merge Sort vs Insertion Sort\n")

sizes = [10, 100, 1000, 5000]

for size in sizes:
    test_list = [random.randint(1, 1000) for _ in range(size)]

    merge_time = timeit.timeit(lambda: merge_sort(test_list[:]), number=10)
    insertion_time = timeit.timeit(lambda: insertion_sort(test_list[:]), number=10)

    print(f"Data size: {size}")
    print(f"Merge Sort Time:     {merge_time:.6f} seconds")
    print(f"Insertion Sort Time: {insertion_time:.6f} seconds")

    if merge_time < insertion_time:
        print("Result: Merge Sort performed better.\n")
    elif insertion_time < merge_time:
        print("Result: Insertion Sort performed better.\n")
    else:
        print("Result: Both performed similarly.\n")
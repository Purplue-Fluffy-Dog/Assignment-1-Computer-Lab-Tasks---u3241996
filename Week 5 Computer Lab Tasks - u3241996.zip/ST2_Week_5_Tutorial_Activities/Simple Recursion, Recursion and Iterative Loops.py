##Simple Recursion

##Recursive Loop
def sum_of_natural_numbers(n):
    if n == 1:
        return 1 # Base case
    else:
        return n + sum_of_natural_numbers(n - 1)
    
result = sum_of_natural_numbers(5)
print(f"The sum of the first 5 natural numbers is {result}")

result = sum_of_natural_numbers(10)
print(f"The sum of the first 10 natural numbers is {result}")

result = sum_of_natural_numbers(20)
print(f"The sum of the first 20 natural numbers is {result}")
    
##Iterative Loop
def sum_of_natural_numbers(n):
    total = 0
    
    for i in range(1, n + 1):
        total += i
        
    return total

result = sum_of_natural_numbers(5)
print(f"The sum of the first 5 natural numbers is {result}")

result = sum_of_natural_numbers(10)
print(f"The sum of the first 10 natural numbers is {result}")

result = sum_of_natural_numbers(20)
print(f"The sum of the first 20 natural numbers is {result}")
##Fibonacci Sequence Recursive and Iterative Loops

#Recursive Loop
# f(n) = f(n - 1) + f(n - 2)
def fibonacci(n):
    if n <= 0:
        return 0 # Base case
    elif n == 1:
        return 1 # Base case 
    else:
        return fibonacci(n - 1) + fibonacci(n - 2) # Recursive case

#Example usage:
result = fibonacci(7)
print(f"The 7th Fibonacci number is {result}")

result = fibonacci(14)
print(f"The 7th Fibonacci number is {result}")

result = fibonacci(21)
print(f"The 7th Fibonacci number is {result}")

#Iterative Loop
def fibonacci(n):
    if n <= 0:
        return 0
    elif n == 1:
        return 1

    a = 0
    b = 1

    for i in range(2, n + 1):
        c = a + b
        a = b
        b = c

    return b

#Example usage:
result = fibonacci(7)
print(f"The 7th Fibonacci number is {result}")

result = fibonacci(14)
print(f"The 7th Fibonacci number is {result}")

result = fibonacci(21)
print(f"The 7th Fibonacci number is {result}")

##Factorial Recursive and Iterative Loops

#Recursive Loop
def factorial(n):
    """
    Recursive function to calculate the factorial of a non-negative integer.

    Args:
    n (int): Non-negative integer for which factorial is calculated.

    Returns:
    int: Factorial of the input integer.
    """
    if n == 0:
        return 1  # Base case: factorial of 0 is 1
    else:
        return n * factorial(n - 1)  # Recursive case: n! = n * (n-1)!

#Example usage:
num = 5
result = factorial(num)
print(f"The factorial of {num} is {result}")

num = 10
result = factorial(num)
print(f"The factorial of {num} is {result}")

num = 20
result = factorial(num)
print(f"The factorial of {num} is {result}")

#Iterative Loop
def factorial(n):
    """
    Iterative function to calculate the factorial of a non-negative integer.
    """
    
    result = 1
    
    for i in range(1, n + 1):
        result = result * i
        
    return result


#Example usage:
num = 5
result = factorial(num)
print(f"The factorial of {num} is {result}")

num = 10
result = factorial(num)
print(f"The factorial of {num} is {result}")

num = 20
result = factorial(num)
print(f"The factorial of {num} is {result}")
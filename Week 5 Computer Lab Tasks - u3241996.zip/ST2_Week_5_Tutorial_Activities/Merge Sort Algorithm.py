import random
import timeit

# -----------------------------
# MERGE SORT
# -----------------------------
def merge_sort(array):
    if len(array) <= 1:
        return array
    else:
        left_split = array[:len(array)//2]
        right_split = array[len(array)//2:]

        left = merge_sort(left_split)
        right = merge_sort(right_split)

        return merge(left, right)


def merge(left, right):
    merged = []
    left_pointer = 0
    right_pointer = 0

    while left_pointer < len(left) and right_pointer < len(right):
        left_element = left[left_pointer]
        right_element = right[right_pointer]

        if left_element < right_element:
            merged.append(left_element)
            left_pointer += 1
        elif right_element < left_element:
            merged.append(right_element)
            right_pointer += 1
        else:  # equal items
            merged.append(left_element)
            merged.append(right_element)
            left_pointer += 1
            right_pointer += 1

    merged.extend(left[left_pointer:])
    merged.extend(right[right_pointer:])

    return merged


# -----------------------------
# INSERTION SORT
# -----------------------------
def insertion_sort(arr):
    for i in range(1, len(arr)):
        current_element = arr[i]
        j = i - 1

        while j >= 0 and current_element < arr[j]:
            arr[j + 1] = arr[j]
            j -= 1

        arr[j + 1] = current_element

    return arr


# -----------------------------
# TEST MERGE SORT FOR DIFFERENT DATA SIZES
# -----------------------------
print("Testing Merge Sort for Different Data Sizes\n")

sizes = [10, 100, 1000, 5000, 10000]

for size in sizes:
    test_list = [random.randint(1, 1000) for _ in range(size)]

    # time merge sort
    merge_time = timeit.timeit(lambda: merge_sort(test_list[:]), number=10)

    print(f"Data size: {size}")
    print(f"Merge Sort took: {merge_time:.6f} seconds\n")


# -----------------------------
# COMPARE MERGE SORT VS INSERTION SORT
# -----------------------------
print("Comparing Merge Sort and Insertion Sort\n")

compare_sizes = [10, 100, 500, 1000]

for size in compare_sizes:
    test_list = [random.randint(1, 1000) for _ in range(size)]

    insertion_time = timeit.timeit(lambda: insertion_sort(test_list[:]), number=10)
    merge_time = timeit.timeit(lambda: merge_sort(test_list[:]), number=10)

    print(f"Data size: {size}")
    print(f"Insertion Sort took: {insertion_time:.6f} seconds")
    print(f"Merge Sort took:     {merge_time:.6f} seconds\n")


# -----------------------------
# CORRECTNESS TEST CASES
# -----------------------------
print("Correctness Test Cases\n")

l = [2, 6, 9, 5, 3, 4, 5, 6, 6, 7]
print("Original list:", l)
print("Sorted list:  ", merge_sort(l))
print()

l = [1]
print("Original list:", l)
print("Sorted list:  ", merge_sort(l))
print()

l = [random.randint(1, 1000) for _ in range(10000)]
sorted_list = merge_sort(l)
print("First 50 sorted values from large list:")
print(sorted_list[:50])

import random
import timeit

# -----------------------------
# INSERTION SORT
# -----------------------------
def insertion_sort(arr):

    for i in range(1, len(arr)):

        current_element = arr[i]
        j = i - 1

        while j >= 0 and current_element < arr[j]:
            arr[j + 1] = arr[j]
            j -= 1

        arr[j + 1] = current_element

    return arr


# -----------------------------
# TEST INSERTION SORT
# -----------------------------
print("Testing Insertion Sort with Different Data Sizes\n")

sizes = [10, 100, 1000, 5000]

for size in sizes:

    # Generate random test data
    test_list = [random.randint(1, 1000) for _ in range(size)]

    # Measure execution time
    insertion_time = timeit.timeit(lambda: insertion_sort(test_list[:]), number=10)

    print(f"Data size: {size}")
    print(f"Insertion Sort took: {insertion_time:.6f} seconds\n")